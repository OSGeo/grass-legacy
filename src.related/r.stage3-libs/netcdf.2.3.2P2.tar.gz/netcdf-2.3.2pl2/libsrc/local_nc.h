/*
 *	Copyright 1993, University Corporation for Atmospheric Research
 *      See netcdf/COPYRIGHT file for copying and redistribution conditions.
 */
/* $Id: local_nc.h,v 1.39 1993/04/27 20:05:21 davis Exp $ */
#ifndef _LOCAL_NC_
#define _LOCAL_NC_

/*
 *	netcdf library 'private' data structures, objects and interfaces
 */

#include	<stddef.h> /* size_t */
#include	<stdio.h> /* FILENAME_MAX */
#ifndef FILENAME_MAX
#define FILENAME_MAX  255
#endif

#ifndef	NO_SYSTEM_XDR_INCLUDES
#include	<rpc/types.h>
#include	<rpc/xdr.h>
#else
#include	<types.h> /* "../xdr/types.h" */
#include	<xdr.h>	 /* "../xdr/xdr.h" */
#endif /* !NO_SYSTEM_XDR_INCLUDES */

#include	"netcdf.h" /* needed for defs of nc_type, ncvoid, ... */

/* ptr argument type in internal functions */
#define Void    char

/* like, a discriminated union in the sense of xdr */
typedef struct {
	nc_type type ;		/* the discriminant */
	size_t len ;		/* the total length originally allocated */
	size_t szof ;		/* sizeof each value */
	unsigned count ;	/* length of the array */
	Void *values ;		/* the actual data */
} NC_array ;

/* Counted string for names and such */
typedef struct {
	unsigned count ;
	char *values ;
} NC_string ;

/* Counted array of ints for assoc list */
typedef struct {
	unsigned count ;
	int *values ;
} NC_iarray ;

/* NC dimension stucture */
typedef struct {
	NC_string *name ;
	long size ;
} NC_dim ;

/* NC attribute */
typedef struct {
	NC_string	*name ;
	NC_array	*data ;
} NC_attr ;

/* NC variable: description and data */
typedef struct {
	NC_string *name ;
	NC_iarray *assoc ; /* user definition */
	unsigned long *shape ; /* compiled info */
	unsigned long *dsizes ; /* compiled info */
	NC_array *attrs;
	nc_type type ;		/* the discriminant */
	unsigned long len ;		/* the total length originally allocated */
	size_t szof ;		/* sizeof each value */
	long begin ;  /* seek index, often an off_t */
} NC_var ;

#define IS_RECVAR(vp) \
	((vp)->shape != NULL ? (*(vp)->shape == NC_UNLIMITED) : 0 )

typedef struct {
	char path[FILENAME_MAX + 1] ;
	unsigned flags ;
	XDR *xdrs ;
	long begin_rec ; /* (off_t) postion of the first 'record' */
	unsigned long recsize ; /* length of 'record' */
	int redefid ;
	/* below gets xdr'd */
	unsigned long numrecs ; /* number of 'records' allocated */
	NC_array *dims ;
	NC_array *attrs ;
	NC_array *vars ;
} NC ;

extern char *cdf_routine_name ; /* defined in lerror.c */

               /*  C D F 1 */
#define	NCMAGIC	0x43444601
                       /*  C D L 1 */
#define	NCLINKMAGIC	0x43444c01

#undef PROTO
#ifndef NO_HAVE_PROTOTYPES 
#   define	PROTO(x)	x
#else
#   define	PROTO(x)	()
#endif

#ifdef __cplusplus
extern "C" {
#endif

extern void		nc_serror			PROTO((
	char *fmt,
	...
)) ;
extern void		NCadvise			PROTO((
	int err,
	char *fmt,
	...
)) ;

extern int        NC_computeshapes	PROTO((
    NC		*handle
));
extern int        NC_xtypelen		PROTO((
    nc_type	type
));
extern int        NC_xlen_array		PROTO((
    NC_array	*array
));
extern int        NC_xlen_attr		PROTO((
    NC_attr	**app
));
extern int        NC_xlen_cdf		PROTO((
    NC		*cdf
));
extern int        NC_xlen_dim		PROTO((
    NC_dim	**dpp
));
extern int        NC_xlen_iarray	PROTO((
    NC_iarray	*iarray
));
extern int        NC_xlen_string	PROTO((
    NC_string	*cdfstr
));
extern int        NC_xlen_var		PROTO((
    NC_var	**vpp
));

extern char       *NCmemset		PROTO((
    char	*s,
    int		c,
    int		n
));

extern void       NC_arrayfill		PROTO((
    Void	*lo,
    size_t	len,
    nc_type	type
));
extern void       NC_copy_arrayvals	PROTO((
    char	*target,
    NC_array	*array
));
extern void       NC_free_array		PROTO((
    NC_array	*array
));
extern void       NC_free_attr		PROTO((
    NC_attr	*attr
));
extern void       NC_free_cdf		PROTO((
    NC		*handle
));
extern void       NC_free_dim		PROTO((
    NC_dim	*dim
));
extern void       NC_free_iarray	PROTO((
    NC_iarray	*iarray
));
extern void       NC_free_string	PROTO((
    NC_string	*cdfstr
));
extern void       NC_free_var		PROTO((
    NC_var	*var
));

extern Void      *NC_incr_array		PROTO((
    NC_array	*array,
    Void	*tail
));

extern bool_t     NCcktype		PROTO((
    nc_type	datatype
));
extern bool_t     NC_indefine		PROTO((
    int		cdfid,
    bool_t	iserr
));
extern bool_t     xdr_cdf		PROTO((
    XDR		*xdrs,
    NC		**handlep
));
extern bool_t     xdr_numrecs		PROTO((
    XDR		*xdrs,
    NC		*handle
));
extern bool_t     xdr_shorts		PROTO((
    XDR		*xdrs,
    short	*sp,
    u_int	cnt
));
extern bool_t     xdr_NC_array		PROTO((
    XDR		*xdrs,
    NC_array	**app
));
extern bool_t     xdr_NC_attr		PROTO((
    XDR		*xdrs,
    NC_attr	**app
));
extern bool_t     xdr_NC_dim		PROTO((
    XDR		*xdrs,
    NC_dim	**dpp
));
extern bool_t     xdr_NC_fill		PROTO((
    XDR		*xdrs,
    NC_var	*vp
));
extern bool_t     xdr_NC_iarray		PROTO((
    XDR		*xdrs,
    NC_iarray	**ipp
));
extern bool_t     xdr_NC_string		PROTO((
    XDR		*xdrs,
    NC_string	**spp
));
extern bool_t     xdr_NC_var		PROTO((
    XDR		*xdrs,
    NC_var	**vpp
));

extern size_t     NC_typelen		PROTO((
    nc_type	type
));

extern NC        *NC_check_id		PROTO((
    int		cdfid
));
extern NC        *NC_dup_cdf		PROTO((
    const char *name,
	int     mode,
    NC		*old
));
extern NC        *NC_new_cdf		PROTO((
    const char *name,
    int		mode
));
extern NC_array  *NC_new_array		PROTO((
    nc_type	type,
    unsigned	count,
    const void	*values
));
extern NC_array  *NC_re_array		PROTO((
    NC_array	*old,
    nc_type	type,
    unsigned	count,
    const void	*values
));
extern NC_attr  **NC_findattr		PROTO((
    NC_array	**ap,
    const char	*name
));
extern NC_dim    *NC_new_dim		PROTO((
    const char	*name,
    long	size
));
extern NC_iarray *NC_new_iarray		PROTO((
    unsigned	count,
    const int		values[]
));
extern NC_string *NC_new_string		PROTO((
    unsigned	count,
    const char	*str
));
extern NC_string *NC_re_string		PROTO((
    NC_string	*old,
    unsigned	count,
    const char	*str
));
extern NC_var    *NC_hlookupvar		PROTO((
    NC		*handle,
    int		varid
));
extern NC_var    *NC_new_var		PROTO((
    const char	*name,
    nc_type	type,
    int		ndims,
    const int		*dims
));
extern int	NCvario			PROTO((
	NC *handle,
	int varid,
	const long *start,
	const long *edges,
	Void *values
));
extern bool_t	NCcoordck	PROTO((
	NC *handle,
	NC_var *vp, 
	const long *coords
));
extern bool_t xdr_NCvshort	PROTO((
	XDR *xdrs,
	unsigned which,
	short *values
));
extern bool_t	NC_dcpy			PROTO((
	XDR *target,
	XDR *source,
	long nbytes
));


#ifdef __cplusplus
}
#endif

#endif /* _LOCAL_NC_ */
