/*********************************************************************
 *   Copyright 1993, UCAR/Unidata
 *   See netcdf/COPYRIGHT file for copying and redistribution conditions.
 *   $Header: /a/zero/home/russ/src/netcdf/ncgen/RCS/generic.h,v 1.2 1993/03/18 05:32:52 russ Exp $
 *********************************************************************/

union generic {			/* used to hold any kind of fill_value */
    double doublev;
    float floatv;
    long longv;
    short shortv;
    char charv;
};
