/*********************************************************************
 *   Copyright 1993, UCAR/Unidata
 *   See netcdf/COPYRIGHT file for copying and redistribution conditions.
 *   $Header: /a/zero/home/russ/src/netcdf/ncgen/RCS/genlib.h,v 1.2 1993/03/18 05:32:57 russ Exp $
 *********************************************************************/

extern char	*progname;	/* for error messages */
extern char	*cdlname;	/* for error messages */

#undef PROTO
#ifndef NO_HAVE_PROTOTYPES 
#   define	PROTO(x)	x
#else
#   define	PROTO(x)	()
#endif

#ifdef __cplusplus
extern "C" {
#endif

extern void	derror		PROTO((
				       char *fmt,
				       ...
				       ));
extern void	*emalloc	PROTO((
				       int size
				       ));
extern void	*erealloc	PROTO((
				       void *ptr,
				       int size
				       ));

#ifdef __cplusplus
}
#endif
