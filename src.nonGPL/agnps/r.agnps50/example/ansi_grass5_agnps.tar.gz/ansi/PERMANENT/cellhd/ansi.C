proj:       1
zone:       16
north:      4487500
south:      4483200
east:       501700
west:       496700
cols:       50
rows:       43
e-w resol:  100
n-s resol:  100
format:     0
compressed: 1
